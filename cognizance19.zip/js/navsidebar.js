function openNav() {
  document.getElementById("mySidenav").className = "sidenav is-active";
}

function closeNav() {
  document.getElementById("mySidenav").className = "sidenav";
}