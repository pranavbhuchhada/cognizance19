<span id="sidebar">
	<a href="javascript:void(0);" class="fa fa-facebook"></a>
	<a href="javascript:void(0);" class="fa fa-instagram"></a>
	<a href="javascript:void(0);" class="fa fa-youtube"></a>
	<a href="javascript:void(0);" class="fa fa-envelope-o"></a>
</span> 