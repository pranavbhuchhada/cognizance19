<span id="mySidenav" class="sidenav">
    <a href="http://www.cz19.in"><img src="/assets/cz_logo.png" class="img-fluid p-5"></a>
    <div id="social">
      <a href="https://www.facebook.com/czCHARUSAT/" class="fa fa-facebook" target="_blank"></a>
      <a href="https://www.instagram.com/cognizance_charusat/" target="_blank" class="fa fa-instagram"></a>
      <a href="https://www.youtube.com/channel/UC5ooaAF54LXWIil2GjUxrhw"  target="_blank" class="fa fa-youtube" ></a>
      <a href="mailto:info@cz19.in?Subject=Inquery%20CZ'19"  class="fa fa-envelope-o"></a>
    </div>
    <a href="javascript:void(0);" class="closebtn" onclick="closeNav();">&times;</a>
    <a href="/" onclick="closeNav();showDashboard();">Home</a>
    <a href="/events/" onclick="closeNav();">Events</a>
    <a href="/attraction/workshops.php" onclick="closeNav();">Workshops</a>
    <a href="javascript:alert('Coming Soon..');" onclick="closeNav();">Guest Lectures</a>
    <a href="javascript:alert('Coming Soon..');" onclick="closeNav();">Pro Night</a>
    <a href="/gallery/" onclick="closeNav();">Gallery</a>
    <a href="/contact-us/" onclick="closeNav();">Contact Us</a>
    <a href="javascript:alert('Coming Soon..');" onclick="closeNav();">Sponsors</a>
    <a href="javascript:alert('Coming Soon..');" onclick="closeNav();">Accomodation</a>
</span>
<span style="font-size:30px;cursor:pointer;padding: 10px;position: fixed;top: 0;left: 0;z-index: 1;" onclick="openNav()">
&#9776;</span>