<!DOCTYPE html>
<html lang="en">
<head>
	<title>Cognizance 19</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Cognizance 2019">
	<meta name="keywords" content="cognizance 2019, Cognizance, 2019, cz2019, cz19, cz, 19, Charusat, charotar, university, techfest, technical, fest, changa, cspit, depstar, events, event, non-tech">
	<meta name="author" content="Pranav Bhuchhada(pranavbhuchhada@gmail.com), chirayu joshi, mitraj jadeja, akash patel">
</head>
<body>
	<?php 
		header("Location: dashboard.php");
	 ?>
</body>
</html>
