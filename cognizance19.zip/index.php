<?php 
header("Location: comingsoon.php");
 ?>